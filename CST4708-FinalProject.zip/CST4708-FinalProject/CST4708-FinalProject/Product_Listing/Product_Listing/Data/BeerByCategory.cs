using System;
using System.Collections.Generic;
namespace Product_Listing
{    
    public class BeerByCategory
    {
        public string catName { get; set; }
        public Nullable<int> beerTotal { get; set; }
    }
}
