using System;
using System.Collections.Generic;
namespace Product_Listing
{
    
    public class BeerByStyleName
    {
        public string beerName { get; set; }
        public string brewery { get; set; }
        public string beerDescription { get; set; }
        public string styleName { get; set; }
        public Nullable<double> price { get; set; }
    }
}
