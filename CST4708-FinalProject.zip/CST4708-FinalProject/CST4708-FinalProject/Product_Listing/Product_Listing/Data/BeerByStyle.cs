using System;
using System.Collections.Generic;

namespace Product_Listing
{
    public class BeerByStyle
    {
        public string styleName { get; set; }
        public Nullable<int> beerTotal { get; set; }
    }
}
