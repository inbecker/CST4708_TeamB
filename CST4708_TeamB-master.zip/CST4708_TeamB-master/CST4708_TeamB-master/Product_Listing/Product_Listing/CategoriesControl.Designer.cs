﻿namespace Product_Listing
{
    partial class CategoriesControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button12;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategoriesControl));
            System.Windows.Forms.Button button11;
            System.Windows.Forms.Button button10;
            System.Windows.Forms.Button button9;
            System.Windows.Forms.Button button8;
            System.Windows.Forms.Button button7;
            this.panel9 = new System.Windows.Forms.Panel();
            button12 = new System.Windows.Forms.Button();
            button11 = new System.Windows.Forms.Button();
            button10 = new System.Windows.Forms.Button();
            button9 = new System.Windows.Forms.Button();
            button8 = new System.Windows.Forms.Button();
            button7 = new System.Windows.Forms.Button();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(button12);
            this.panel9.Controls.Add(button11);
            this.panel9.Controls.Add(button10);
            this.panel9.Controls.Add(button9);
            this.panel9.Controls.Add(button8);
            this.panel9.Controls.Add(button7);
            this.panel9.Location = new System.Drawing.Point(0, 24);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(651, 294);
            this.panel9.TabIndex = 16;
            // 
            // button12
            // 
            button12.FlatAppearance.BorderSize = 0;
            button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button12.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button12.Location = new System.Drawing.Point(464, 191);
            button12.Name = "button12";
            button12.Size = new System.Drawing.Size(150, 54);
            button12.TabIndex = 11;
            button12.Text = "Witbier";
            button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.FlatAppearance.BorderSize = 0;
            button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button11.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button11.Location = new System.Drawing.Point(251, 191);
            button11.Name = "button11";
            button11.Size = new System.Drawing.Size(150, 54);
            button11.TabIndex = 10;
            button11.Text = "Pilsner";
            button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button10.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button10.Location = new System.Drawing.Point(38, 191);
            button10.Name = "button10";
            button10.Size = new System.Drawing.Size(150, 54);
            button10.TabIndex = 9;
            button10.Text = "Porter";
            button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button9.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button9.Location = new System.Drawing.Point(464, 58);
            button9.Name = "button9";
            button9.Size = new System.Drawing.Size(150, 54);
            button9.TabIndex = 8;
            button9.Text = "Pale Ale";
            button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button8.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button8.Location = new System.Drawing.Point(38, 58);
            button8.Name = "button8";
            button8.Size = new System.Drawing.Size(150, 54);
            button8.TabIndex = 7;
            button8.Text = "Ale";
            button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button7.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold);
            button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button7.Location = new System.Drawing.Point(251, 58);
            button7.Name = "button7";
            button7.Size = new System.Drawing.Size(150, 54);
            button7.TabIndex = 6;
            button7.Text = "Lager";
            button7.UseVisualStyleBackColor = true;
            // 
            // CategoriesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel9);
            this.Name = "CategoriesControl";
            this.Size = new System.Drawing.Size(651, 350);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel9;
    }
}
